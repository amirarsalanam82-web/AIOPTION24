package com.aioption24;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.*;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends Activity {
    private static final String KS="AndroidKeyStore", ALIAS="AIOPTION24_KEY";
    private android.content.SharedPreferences prefs;
    private SecretKey key() throws Exception {
        KeyStore ks=KeyStore.getInstance(KS); ks.load(null);
        if(!ks.containsAlias(ALIAS)){ KeyGenerator kg=KeyGenerator.getInstance("AES",KS); kg.init(256); kg.generateKey(); }
        return ((KeyStore.SecretKeyEntry)ks.getEntry(ALIAS,null)).getSecretKey();
    }
    private String enc(String s) throws Exception {
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE,key());
        return Base64.encodeToString(c.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(c.doFinal(s.getBytes(StandardCharsets.UTF_8)),Base64.NO_WRAP);
    }
    private String dec(String s) throws Exception {
        String[] p=s.split(":",2); Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(p[0],Base64.NO_WRAP)));
        return new String(c.doFinal(Base64.decode(p[1],Base64.NO_WRAP)),StandardCharsets.UTF_8);
    }
    @Override public void onCreate(Bundle b){ super.onCreate(b); prefs=getSharedPreferences("secure",0);
        WebView w=new WebView(this); w.setBackgroundColor(0xFF080808); w.getSettings().setJavaScriptEnabled(true); w.getSettings().setDomStorageEnabled(true); w.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        w.addJavascriptInterface(new Object(){
            @JavascriptInterface public void saveKeys(String api,String secret){ try{ prefs.edit().putString("api",enc(api)).putString("secret",enc(secret)).apply(); w.post(()->w.evaluateJavascript("window.onNativeSaved&&window.onNativeSaved()",null)); }catch(Exception e){} }
            @JavascriptInterface public String hasKeys(){ return prefs.contains("api")&&prefs.contains("secret")?"1":"0"; }
            @JavascriptInterface public String clearKeys(){ prefs.edit().clear().apply(); return "1"; }
        },"NativeVault");
        w.setWebViewClient(new WebViewClient()); w.loadUrl("file:///android_asset/index.html"); setContentView(w);
    }
}
