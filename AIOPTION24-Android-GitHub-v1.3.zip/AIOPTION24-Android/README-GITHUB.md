# AIOPTION 24 — GitHub APK Build

این نسخه برای ساخت APK مستقیم با GitHub Actions آماده شده است و نیازی به کامپیوتر ندارد.

## ساخت APK
1. کل محتویات این پوشه را داخل یک Repository در GitHub آپلود کنید.
2. وارد تب **Actions** شوید.
3. Workflow با نام **Build AIOPTION 24 APK** را انتخاب کنید.
4. روی **Run workflow** بزنید.
5. بعد از سبز شدن Build، در صفحه اجرای Workflow بخش **Artifacts**، فایل `AIOPTION24-v1.1-debug` را دریافت کنید.
6. فایل APK را روی گوشی نصب کنید.

## نکات امنیتی
- API Key و Secret مربوط به Wallex را در GitHub، کد یا ChatGPT قرار ندهید.
- این APK برای تست و دمو است و اتصال معامله واقعی هنوز باید از طریق یک Backend امن پیاده‌سازی شود.
- نسخه debug برای نصب روی گوشی مناسب است. برای انتشار عمومی، یک signing key ثابت باید خارج از مخزن نگهداری و به GitHub Secrets متصل شود.
